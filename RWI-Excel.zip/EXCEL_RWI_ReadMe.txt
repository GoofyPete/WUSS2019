Start SAS and navigate to the directory where the files were unzipped

In the Code directory, open RWI_Excel_Setup.sas

Change the path in the macro variable RootDir to wherever you copied the files

The examples should now all work...